export class Employee{
    username: string;
    firstName: string;
    lastName: string;
    address: string;
    phone: string;
    website: string;
    personalData: string;
    title: string;
    cabinet: string;
    status: string;
    imageName: string;
}