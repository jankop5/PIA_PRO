export class Attending{
    username: string;
    coursename: string;
}