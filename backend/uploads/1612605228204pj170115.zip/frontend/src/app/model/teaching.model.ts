export class Teaching{
    username: string;
    coursename: string;
    group: string;
}