export class StudentsList{
    idL: number;
    coursename: string;
    usernames: string[];
    originalFileNames: string[];
    uploadFileNames: string[];
    title: string;
    date: string;
    place: boolean;
    limit: number;
    closed: boolean;
}