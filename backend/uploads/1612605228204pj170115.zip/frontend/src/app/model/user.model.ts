export class User{
    username: string;
    type: number;
    passwordChanged: boolean;
}