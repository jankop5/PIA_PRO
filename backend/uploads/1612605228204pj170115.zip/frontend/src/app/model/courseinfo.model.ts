export class CourseInfo{
    coursename: string;
    code: string;
    type: string;
    lessions: string;
    espb: number;
    terms: string;
    module:  string;
    semester: number;
    goal: string;
    outcome: string;
    propositions: string;
}