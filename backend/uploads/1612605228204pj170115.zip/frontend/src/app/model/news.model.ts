export class News{
    idN: number;
    title: string;
    text: string;
    category: string;
    date: string;
}