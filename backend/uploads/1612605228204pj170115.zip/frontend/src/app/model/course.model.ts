export class Course{
    coursename: string;
    codes: string[];
    showExams: boolean;
    showLabs: boolean;
    showProject: boolean;
    labInfo: string;
    projectInfo: string;
}