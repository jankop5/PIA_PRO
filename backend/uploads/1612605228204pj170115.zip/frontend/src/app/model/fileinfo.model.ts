export class FileInfo{
    uploadName: string;
    originalName: string;
    coursename: string;
    type: string;
    size: number;
    kind: string;
    date: string;
    teacher: string;
    order: number;
}