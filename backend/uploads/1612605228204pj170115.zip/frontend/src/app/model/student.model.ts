export class Student{
    username: string;
    firstName: string;
    lastName: string;
    index: string;
    typeOfStudy: string;
    status: string;
}