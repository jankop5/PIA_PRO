export class Notice{
    idN: number;
    title: string;
    text: string;
    uploadNames: Array<string>;
    originalNames: Array<string>;
    codes: Array<string>;
    date: string;
    teacher: string;
}