import { Component, OnInit } from '@angular/core';

/**
 * @module
 * komponenta za prikaz projekata nastavnickog osoblja katedre
 */
@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})
export class ProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
