INSERT INTO artikal(Naziv, IdT, IdV, IdB, Pol)
VALUES("artikal14", 9, 2, 3, 'M');

INSERT INTO artikal(Naziv, IdT, IdV, IdB, Pol)
VALUES("artikal15", 8, 4, 1, 'Z');

INSERT INTO ponuda(IdA, PIB, Cena)
VALUES (2, 1004, 400);

INSERT INTO ponuda(IdA, PIB, Cena)
VALUES (14, 1010, 2000);

INSERT INTO ponuda(IdA, PIB, Cena)
VALUES (15, 1007, 50);

INSERT INTO narudzbina(MatBr, Status)
VALUES (1234567890005, 'O');

INSERT INTO obuhvata
VALUES(22, 14, 4);

INSERT INTO narudzbina(MatBr, Status)
VALUES (1234567890006, 'O');

INSERT INTO obuhvata
VALUES(23, 15, 1);

UPDATE narudzbina
SET Status = 'O', DatumVreme = now()
WHERE IdN = 1;
