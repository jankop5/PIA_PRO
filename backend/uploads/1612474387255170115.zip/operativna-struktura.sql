-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: operativna
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artikal`
--

DROP TABLE IF EXISTS `artikal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artikal` (
  `IdA` int(11) NOT NULL AUTO_INCREMENT,
  `Naziv` varchar(45) NOT NULL,
  `IdT` int(11) NOT NULL,
  `IdV` int(11) NOT NULL,
  `IdB` int(11) NOT NULL,
  `Pol` char(1) NOT NULL,
  `DatumVremeKreiranja` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`IdA`),
  KEY `IdTFK_idx` (`IdT`),
  KEY `IdVFK_idx` (`IdV`),
  KEY `IdBFK_idx` (`IdB`),
  CONSTRAINT `IdBFK` FOREIGN KEY (`IdB`) REFERENCES `boja` (`IdB`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `IdTFK` FOREIGN KEY (`IdT`) REFERENCES `tip` (`IdT`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `IdVFK` FOREIGN KEY (`IdV`) REFERENCES `velicina` (`IdV`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `boja`
--

DROP TABLE IF EXISTS `boja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boja` (
  `IdB` int(11) NOT NULL AUTO_INCREMENT,
  `Boja` varchar(45) NOT NULL,
  PRIMARY KEY (`IdB`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `grad`
--

DROP TABLE IF EXISTS `grad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grad` (
  `IdG` int(11) NOT NULL AUTO_INCREMENT,
  `Grad` varchar(45) NOT NULL,
  PRIMARY KEY (`IdG`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kupac`
--

DROP TABLE IF EXISTS `kupac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kupac` (
  `MatBr` char(13) NOT NULL,
  `Ime` varchar(45) NOT NULL,
  `Pol` char(1) NOT NULL,
  `Uzrast` varchar(45) NOT NULL,
  `DatumVremeKreiranja` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`MatBr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `narudzbina`
--

DROP TABLE IF EXISTS `narudzbina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `narudzbina` (
  `IdN` int(11) NOT NULL AUTO_INCREMENT,
  `MatBr` char(13) NOT NULL,
  `DatumVreme` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Status` char(1) NOT NULL,
  PRIMARY KEY (`IdN`),
  KEY `MatBrFK_idx` (`MatBr`),
  CONSTRAINT `MatBrFK` FOREIGN KEY (`MatBr`) REFERENCES `kupac` (`MatBr`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `obuhvata`
--

DROP TABLE IF EXISTS `obuhvata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `obuhvata` (
  `IdN` int(11) NOT NULL,
  `IdPon` int(11) NOT NULL,
  `Kolicina` int(11) NOT NULL,
  PRIMARY KEY (`IdN`,`IdPon`),
  KEY `IdPonFK_idx` (`IdPon`),
  CONSTRAINT `IdNFK` FOREIGN KEY (`IdN`) REFERENCES `narudzbina` (`IdN`),
  CONSTRAINT `IdPonFK` FOREIGN KEY (`IdPon`) REFERENCES `ponuda` (`IdPon`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `opstina`
--

DROP TABLE IF EXISTS `opstina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opstina` (
  `IdO` int(11) NOT NULL AUTO_INCREMENT,
  `Opstina` varchar(45) NOT NULL,
  `IdG` int(11) NOT NULL,
  PRIMARY KEY (`IdO`),
  KEY `IdGFK_idx` (`IdG`),
  CONSTRAINT `IdGFK` FOREIGN KEY (`IdG`) REFERENCES `grad` (`IdG`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ponuda`
--

DROP TABLE IF EXISTS `ponuda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ponuda` (
  `IdPon` int(11) NOT NULL AUTO_INCREMENT,
  `IdA` int(11) NOT NULL,
  `PIB` varchar(45) NOT NULL,
  `Cena` int(11) NOT NULL,
  `DatumVreme` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`IdPon`),
  KEY `IdAFK_idx` (`IdA`),
  KEY `PIBFK_idx` (`PIB`),
  CONSTRAINT `IdAFK` FOREIGN KEY (`IdA`) REFERENCES `artikal` (`IdA`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `PIBFK` FOREIGN KEY (`PIB`) REFERENCES `prodavac` (`PIB`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prodavac`
--

DROP TABLE IF EXISTS `prodavac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prodavac` (
  `PIB` varchar(45) NOT NULL,
  `Naziv` varchar(45) NOT NULL,
  `Ulica` varchar(45) NOT NULL,
  `Broj` int(11) NOT NULL,
  `IdO` int(11) NOT NULL,
  PRIMARY KEY (`PIB`),
  KEY `IdOFK_idx` (`IdO`),
  CONSTRAINT `IdOFK` FOREIGN KEY (`IdO`) REFERENCES `opstina` (`IdO`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tip`
--

DROP TABLE IF EXISTS `tip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tip` (
  `IdT` int(11) NOT NULL AUTO_INCREMENT,
  `Tip` varchar(45) NOT NULL,
  PRIMARY KEY (`IdT`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `velicina`
--

DROP TABLE IF EXISTS `velicina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `velicina` (
  `IdV` int(11) NOT NULL AUTO_INCREMENT,
  `Velicina` varchar(45) NOT NULL,
  PRIMARY KEY (`IdV`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-03 19:24:18
