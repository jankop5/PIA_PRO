-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: operativna
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `artikal`
--

LOCK TABLES `artikal` WRITE;
/*!40000 ALTER TABLE `artikal` DISABLE KEYS */;
INSERT INTO `artikal` VALUES (1,'artikal1',1,1,1,'M','2021-02-02 14:58:22'),(2,'artikal2',1,1,1,'Z','2021-02-02 15:00:00'),(3,'artikal3',3,3,3,'M','2021-02-02 17:21:21'),(4,'artikal4',4,4,4,'M','2021-02-02 17:22:46'),(5,'artikal5',5,5,5,'Z','2021-02-02 17:22:46'),(6,'artikal6',6,6,6,'M','2021-02-02 17:22:46'),(7,'artikal7',7,7,7,'M','2021-02-02 17:22:46'),(8,'artikal8',8,8,8,'Z','2021-02-02 17:22:46'),(9,'artikal9',9,9,9,'Z','2021-02-02 17:22:46'),(10,'artikal10',10,10,10,'M','2021-02-02 17:22:46'),(11,'artikal11',2,1,4,'Z','2021-02-02 17:22:46'),(12,'artikal12',4,7,2,'Z','2021-02-02 21:49:23'),(13,'artikal13',5,7,3,'M','2021-02-02 21:50:43');
/*!40000 ALTER TABLE `artikal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `boja`
--

LOCK TABLES `boja` WRITE;
/*!40000 ALTER TABLE `boja` DISABLE KEYS */;
INSERT INTO `boja` VALUES (1,'zelena'),(2,'crvena'),(3,'plava'),(4,'zuta'),(5,'bela'),(6,'crna'),(7,'ljubicasta'),(8,'roze'),(9,'narandzasta'),(10,'zlatna'),(11,'siva'),(12,'braon');
/*!40000 ALTER TABLE `boja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `grad`
--

LOCK TABLES `grad` WRITE;
/*!40000 ALTER TABLE `grad` DISABLE KEYS */;
INSERT INTO `grad` VALUES (1,'Raska'),(2,'Kraljevo'),(3,'Valjevo'),(4,'Novi Pazar'),(5,'Beograd'),(6,'Novi Sad'),(7,'Subotica'),(8,'Vranje'),(9,'Sombor'),(10,'Nis'),(11,'Kragujevac'),(12,'Cacak');
/*!40000 ALTER TABLE `grad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `kupac`
--

LOCK TABLES `kupac` WRITE;
/*!40000 ALTER TABLE `kupac` DISABLE KEYS */;
INSERT INTO `kupac` VALUES ('1234567890001','ime1','M','dete','2021-02-02 17:44:38'),('1234567890002','ime2','Z','deca','2021-02-02 17:44:38'),('1234567890003','ime3','Z','deca','2021-02-02 17:44:38'),('1234567890004','ime4','M','bebe','2021-02-02 17:44:38'),('1234567890005','ime5','Z','bebe','2021-02-02 17:44:38'),('1234567890006','ime6','Z','adolescenti','2021-02-02 17:44:38'),('1234567890007','ime7','M','adolescenti','2021-02-02 17:44:38'),('1234567890008','ime8','M','adolescenti','2021-02-02 17:44:38'),('1234567890009','ime9','M','adolescenti','2021-02-02 17:44:38'),('1234567890010','ime10','Z','odrasli','2021-02-02 17:44:38'),('1234567890011','ime11','Z','odrasli','2021-02-02 17:44:38'),('1234567890012','ime12','Z','odrasli','2021-02-02 17:44:38'),('1234567890013','ime13','M','penzioneri','2021-02-02 17:44:38'),('1234567890014','ime14','Z','penzioneri','2021-02-02 17:44:38');
/*!40000 ALTER TABLE `kupac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `narudzbina`
--

LOCK TABLES `narudzbina` WRITE;
/*!40000 ALTER TABLE `narudzbina` DISABLE KEYS */;
INSERT INTO `narudzbina` VALUES (1,'1234567890001','2021-02-02 17:50:42','K'),(2,'1234567890001','2021-02-02 17:52:44','O'),(3,'1234567890001','2021-02-02 17:52:44','N'),(4,'1234567890002','2021-02-02 17:52:44','K'),(5,'1234567890002','2021-02-02 17:52:44','N'),(6,'1234567890002','2021-02-02 17:52:44','O'),(7,'1234567890003','2021-02-02 17:52:44','K'),(8,'1234567890003','2021-02-02 17:52:44','O'),(9,'1234567890003','2021-02-02 17:52:44','O'),(10,'1234567890004','2021-02-02 17:52:44','N'),(11,'1234567890005','2021-02-02 17:52:44','N'),(12,'1234567890006','2021-02-02 17:52:44','N'),(13,'1234567890008','2021-02-02 17:52:44','O'),(14,'1234567890007','2021-02-02 17:52:44','O'),(15,'1234567890006','2021-02-02 17:52:44','K'),(16,'1234567890009','2021-02-02 17:52:44','O'),(17,'1234567890009','2021-02-02 17:52:44','O'),(18,'1234567890002','2021-02-02 17:52:44','K'),(19,'1234567890002','2021-02-02 21:40:35','O'),(20,'1234567890003','2021-02-02 21:50:43','O'),(21,'1234567890004','2021-02-03 19:00:14','O');
/*!40000 ALTER TABLE `narudzbina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `obuhvata`
--

LOCK TABLES `obuhvata` WRITE;
/*!40000 ALTER TABLE `obuhvata` DISABLE KEYS */;
INSERT INTO `obuhvata` VALUES (1,1,1),(1,2,3),(2,1,2),(2,2,10),(2,9,2),(3,4,5),(4,4,4),(5,3,1),(5,5,5),(5,8,2),(5,11,1),(6,4,5),(7,2,1),(7,9,4),(7,10,1),(8,3,1),(8,11,1),(9,8,2),(9,12,5),(9,13,1),(10,2,3),(13,13,1),(14,14,1),(15,14,3),(16,14,3),(17,17,10),(18,1,1),(19,10,1),(20,10,4);
/*!40000 ALTER TABLE `obuhvata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `opstina`
--

LOCK TABLES `opstina` WRITE;
/*!40000 ALTER TABLE `opstina` DISABLE KEYS */;
INSERT INTO `opstina` VALUES (1,'Raska',1),(2,'Usce',2),(3,'Kraljevo',2),(4,'Valjevo',3),(5,'Lajkovac',3),(6,'Novi Pazar',4),(7,'Vracar',5),(8,'Stari grad',5),(9,'Novi Beograd',5),(10,'Cukarica',5),(11,'Palilula',5),(12,'Rakovica',5),(13,'Savski venac',5),(14,'Vozdovac',5),(15,'Zemun',5),(16,'Zvezdara',5),(17,'Barajevo',5),(18,'Grocka',5),(19,'Lazarevac',5),(20,'Mladenovac',5),(21,'Obrenovac',5),(22,'Sopot',5),(23,'Surcin',5);
/*!40000 ALTER TABLE `opstina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ponuda`
--

LOCK TABLES `ponuda` WRITE;
/*!40000 ALTER TABLE `ponuda` DISABLE KEYS */;
INSERT INTO `ponuda` VALUES (1,1,'1001',500,'2021-02-02 17:46:32'),(2,2,'1001',500,'2021-02-02 17:48:37'),(3,1,'1002',300,'2021-02-02 17:48:37'),(4,2,'1002',400,'2021-02-02 17:48:37'),(5,1,'1003',150,'2021-02-02 17:48:37'),(6,3,'1003',1000,'2021-02-02 17:48:37'),(7,3,'1004',3000,'2021-02-02 17:48:37'),(8,5,'1004',240,'2021-02-02 17:48:37'),(9,5,'1005',320,'2021-02-02 17:48:37'),(10,8,'1001',3000,'2021-02-02 17:48:37'),(11,8,'1010',3050,'2021-02-02 17:48:37'),(12,6,'1010',3060,'2021-02-02 17:48:37'),(13,7,'1004',2700,'2021-02-02 17:48:37'),(14,4,'1006',290,'2021-02-03 18:55:39'),(15,5,'1006',390,'2021-02-03 18:55:45'),(16,7,'1008',945,'2021-02-03 18:56:08'),(17,9,'1001',444,'2021-02-03 18:56:18');
/*!40000 ALTER TABLE `ponuda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `prodavac`
--

LOCK TABLES `prodavac` WRITE;
/*!40000 ALTER TABLE `prodavac` DISABLE KEYS */;
INSERT INTO `prodavac` VALUES ('1001','prodavac1','ulica1',1,1),('1002','prodavac2','ulica2',2,2),('1003','prodavac3','ulica3',3,3),('1004','prodavac4','ulica4',4,4),('1005','prodavac5','ulica5',5,5),('1006','prodavac6','ulica5',6,5),('1007','prodavac7','ulica5',7,5),('1008','prodavac8','ulica8',8,6),('1009','prodavac9','ulica8',9,6),('1010','prodavac10','ulica9',10,7),('1011','prodavac11','ulica11',11,6);
/*!40000 ALTER TABLE `prodavac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tip`
--

LOCK TABLES `tip` WRITE;
/*!40000 ALTER TABLE `tip` DISABLE KEYS */;
INSERT INTO `tip` VALUES (1,'majica'),(2,'pantalone'),(3,'kajs'),(4,'torba'),(5,'jakna'),(6,'kosulja'),(7,'patike'),(8,'cipele'),(9,'cizme'),(10,'kapa'),(11,'sorts');
/*!40000 ALTER TABLE `tip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `velicina`
--

LOCK TABLES `velicina` WRITE;
/*!40000 ALTER TABLE `velicina` DISABLE KEYS */;
INSERT INTO `velicina` VALUES (1,'XL'),(2,'XXS'),(3,'XS'),(4,'S'),(5,'M'),(6,'L'),(7,'XL'),(8,'XXL'),(9,'XXXL'),(10,'36'),(11,'38'),(12,'40'),(13,'42'),(14,'45');
/*!40000 ALTER TABLE `velicina` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-03 19:25:54
